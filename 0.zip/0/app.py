from flask import Flask, request, jsonify
from models import db, User
from config import Config
app = Flask(__name__)
db.init_app(app)
with app.app_context():
    db.create_all()
@app.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    if User.query.filter_by(email=email).first() or User.query.filter_by(username=username).first():
        return jsonify({"message": "User already exists"}), 400
    new_user = User(
        username=username,
        email=email,
        password_hash=User.hash_password(password)
    )
    db.session.add(new_user)
    db.session.commit()
    return jsonify({"message": "User created successfully"}), 201
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    user = User.query.filter_by(email=email).first()
    if user and user.verify_password(password):
        return jsonify({"message": "Login successful", "user_id": user.id}), 200
    return jsonify({"message": "Invalid email or password"}), 401
@app.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    return jsonify([
        {"id": user.id, "username": user.username, "email": user.email} for user in users
    ]), 200
if __name__ == '__main__':
    app.run(debug=True)